package de.voidplus.soundcloud;

public class SoundCloud {
	// https://github.com/voidplus/soundcloud-java-library
	// https://github.com/voidplus/soundcloud-java-library/blob/master/src/main/java/de/voidplus/soundcloud/SoundCloud.java
	
	// TODO Add internal magic stuff (in combination with Minim).
}
